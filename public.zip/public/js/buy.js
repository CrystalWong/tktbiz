$(function(){
	$('#submit').on('click', function(){
		window.location.href = '/result.html'
	})
})